﻿using System;
using Microsoft.Xna.Framework;
using System.Collections.Generic;
using Microsoft.Xna.Framework.Graphics;
using CSharp_Expert.Opdracht3.Behaviour;

namespace CSharp_Expert.Opdracht3.BaseClass;

public abstract class SceneBase
{
    protected List<GameObject> GameObjects { get; private set; }

    public SceneBase(GraphicsDeviceManager graphics)
    {
        GameObjects = new List<GameObject>();
    }

    public virtual void Initialize()
    {
    }

    public void ClearObjects()
    {
        GameObjects.Clear();
    }

    public virtual void Update(GameTime gameTime)
    {
        foreach (var gameObject in GameObjects)
        {
            //Console.WriteLine($"GameObject Position: {gameObject.Transform.Position}");
            gameObject.Update(gameTime);
        }
        //Console.WriteLine(GameObjects[1].GetComponent<Rotater>());
        //Console.WriteLine(GameObjects[1].Transform.Rotation);
        //Console.WriteLine(GameObjects[2].GetComponent<Rotater>());
        //Console.WriteLine(GameObjects[2].Transform.Rotation);



    }

    public virtual void Draw(SpriteBatch spriteBatch)
    {
        foreach (var gameObject in GameObjects)
        {
            gameObject.Draw(spriteBatch);
        }
    }
}